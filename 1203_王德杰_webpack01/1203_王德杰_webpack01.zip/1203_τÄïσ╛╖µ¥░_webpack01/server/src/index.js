import logo from './images/logo.png';
import css from './css/css.css';
import fn from './fn';


console.log("加载index.js");
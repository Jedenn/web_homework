import logo from './images/logo.png';
import css from './css/css.css';
import fn from './fn';


let btn = document.querySelector("#btn");
btn.addEventListener("click", function (){
    console.log("开课吧-王德杰");
})
